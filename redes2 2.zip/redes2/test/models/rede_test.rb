require "test_helper"

class RedeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
